# Ubuntu-learning

通过给自己电脑安装Ubuntu16.04 desktop和CentOS server实践所得的学习笔记,本着以后不想瞎折腾的原因,存放在这里

包目录下包含很多配置Ubuntu的常用命令和搭建环境必备的技能和教程

仅供学习交流,谢谢阅读.

参考教程:来自慕课网
快速上手Linux 玩转典型应用 编程浪子
https://coding.imooc.com/learn/list/154.html
